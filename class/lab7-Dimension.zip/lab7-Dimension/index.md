Title: Lab 07: Principal Components Analysis (PCA)
Category: labs
Slug: lab07
Lab Instructor: Pengfei FAN
Date: 2022-11-15
Tags:  principal components analysis, logistic regression, big data, dimensionality  reduction, explained variance, MNIST, clustering

## Jupyter Notebooks

- [Lab  7: Principal Components Analysis (PCA)]({static}notebook/lab_07_solutions.ipynb)
