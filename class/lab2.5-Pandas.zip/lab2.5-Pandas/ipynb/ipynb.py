"""
This file is needed to make pelican work :)
"""
from .core import *
